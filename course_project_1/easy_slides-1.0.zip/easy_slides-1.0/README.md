# easyslides
Easy slides template for LaTeX users, based on the article class.
